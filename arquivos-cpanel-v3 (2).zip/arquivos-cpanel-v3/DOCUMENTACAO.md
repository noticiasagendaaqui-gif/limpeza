# 📱 AutoLimpeza Pro - Documentação Completa

## 🏗️ **Tecnologias Utilizadas**

### **Frontend (Interface do Usuário)**
- **React 18** - Biblioteca JavaScript para interfaces
- **TypeScript** - JavaScript com tipagem estática
- **Vite** - Ferramenta de build rápida e moderna
- **Tailwind CSS** - Framework CSS utility-first
- **Wouter** - Roteamento leve para React
- **Lucide React** - Biblioteca de ícones moderna

### **Componentes UI**
- **Shadcn/UI** - Componentes acessíveis e customizáveis
- **Radix UI** - Primitivos de UI com acessibilidade
- **React Hook Form** - Gerenciamento de formulários
- **Zod** - Validação de dados TypeScript-first

### **Estado e Dados**
- **TanStack Query** - Gerenciamento de estado do servidor
- **React Query** - Cache e sincronização de dados

### **Backend (Servidor)**
- **Node.js** - Runtime JavaScript
- **Express.js** - Framework web para Node.js
- **TypeScript** - Tipagem estática
- **Drizzle ORM** - ORM moderno para TypeScript

### **Banco de Dados**
- **PostgreSQL** - Banco de dados relacional
- **Neon Database** - PostgreSQL serverless (produção)
- **Memória** - Armazenamento local (desenvolvimento)

### **Build e Deploy**
- **ESBuild** - Bundler JavaScript ultra-rápido
- **PostCSS** - Processador CSS
- **Autoprefixer** - Prefixos CSS automáticos

---

## 📋 **Estrutura do Projeto**

```
AutoLimpeza-Pro/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── components/     # Componentes React
│   │   ├── pages/         # Páginas da aplicação
│   │   ├── hooks/         # Hooks customizados
│   │   └── lib/           # Utilitários
│   └── index.html         # Template HTML
├── server/                # Backend Express
│   ├── index.ts          # Servidor principal
│   ├── routes.ts         # Rotas da API
│   └── storage.ts        # Interface de dados
├── shared/               # Código compartilhado
│   └── schema.ts        # Esquemas de dados
├── dist/                # Arquivos compilados
├── package.json         # Dependências
└── arquivos-cpanel-v2/  # Arquivos para upload
```

---

## 🌐 **Instalação no cPanel**

### **Pré-requisitos**
- Conta de hospedagem com cPanel
- Acesso ao Gerenciador de Arquivos
- Domínio configurado

### **Passo a Passo**

#### **1. Preparar Arquivos**
```bash
# No Replit ou computador local
npm install
npm run build
```

#### **2. Baixar Arquivos para Upload**
- No Replit: Baixe a pasta `arquivos-cpanel-v2`
- Extraia o arquivo ZIP no seu computador

#### **3. Acessar cPanel**
- Entre na sua conta de hospedagem
- Acesse o painel cPanel
- Clique em "Gerenciador de Arquivos"

#### **4. Navegar para Pasta Pública**
- Vá para a pasta `public_html/`
- Esta é a pasta raiz do seu site

#### **5. Upload dos Arquivos**
- Faça upload de todos os arquivos de `arquivos-cpanel-v2/`
- Estrutura final:
```
public_html/
├── index.html
├── assets/
│   ├── index-[hash].css
│   └── index-[hash].js
```

#### **6. Configurar .htaccess (Opcional)**
Crie um arquivo `.htaccess` em `public_html/`:
```apache
# Redirecionar para index.html
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]

# Cache de arquivos estáticos
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/webp "access plus 1 year"
</IfModule>

# Compressão GZIP
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>
```

#### **7. Verificar Instalação**
- Acesse `seudominio.com`
- Teste todas as funcionalidades:
  - Menu mobile
  - Botões WhatsApp
  - Formulário de orçamento
  - Navegação entre seções

---

## 🔄 **Como Atualizar o Site**

### **Processo de Atualização**

#### **1. Fazer Alterações**
- Edite os arquivos no Replit
- Teste as mudanças na prévia

#### **2. Gerar Nova Versão**
```bash
npm run build
```

#### **3. Preparar Arquivos**
- Nova pasta será criada: `arquivos-cpanel-v[numero]`
- Baixe esta pasta

#### **4. Backup do Site Atual**
**No cPanel:**
- Selecione todos os arquivos em `public_html/`
- Compacte em `backup-[data].zip`
- Baixe o backup

#### **5. Substituir Arquivos**
**Método Seguro:**
1. Crie pasta temporária: `public_html/novo/`
2. Upload dos novos arquivos em `/novo/`
3. Teste acessando `seudominio.com/novo/`
4. Se OK, mova arquivos para `public_html/`

**Método Rápido:**
1. Delete arquivos antigos (exceto .htaccess)
2. Upload dos novos arquivos
3. Teste o site

#### **6. Verificar Funcionalidades**
- ✅ Site carrega corretamente
- ✅ WhatsApp funciona
- ✅ Formulários funcionam
- ✅ Menu mobile responde
- ✅ Design responsivo OK

---

## 📱 **Funcionalidades do Sistema**

### **Seções Principais**
- **Header Mobile** - Logo e menu hamburger
- **Hero Section** - Chamada principal com estatísticas
- **Serviços** - Grid com filtros (Automotivo/Residencial)
- **Galeria** - Antes e depois dos trabalhos
- **Depoimentos** - Avaliações de clientes
- **Formulário** - Solicitação de orçamento
- **Áreas** - Regiões de atendimento
- **Navegação** - Menu inferior fixo

### **Integrações**
- **WhatsApp** - (31) 98025-2882
- **Formulários** - Envio automático via WhatsApp
- **Responsivo** - Mobile-first design

---

## 🛠️ **Troubleshooting**

### **Problemas Comuns**

#### **Site não carrega**
- ✅ Verificar se `index.html` está na raiz
- ✅ Conferir permissões dos arquivos (644)
- ✅ Verificar .htaccess

#### **CSS não aparece**
- ✅ Verificar caminhos dos arquivos
- ✅ Limpar cache do navegador
- ✅ Verificar se pasta `assets/` foi carregada

#### **WhatsApp não funciona**
- ✅ Verificar número (31) 98025-2882
- ✅ Testar links manualmente
- ✅ Verificar se é HTTPS

#### **Menu não clica**
- ✅ Limpar cache
- ✅ Verificar JavaScript carregou
- ✅ Testar em navegador diferente

### **Logs de Erro**
- Pressione F12 no navegador
- Vá na aba "Console"
- Verifique se há erros em vermelho

---

## 📊 **Hospedagens Recomendadas**

### **Para Sites Estáticos (Recomendado)**
- ✅ **Hostinger** - R$ 7,99/mês
- ✅ **Hostgator** - R$ 12,99/mês  
- ✅ **Locaweb** - R$ 14,90/mês
- ✅ **GoDaddy** - R$ 19,99/mês

### **Para Sites com Backend**
- ✅ **VPS Hostinger** - R$ 39,99/mês
- ✅ **DigitalOcean** - $6/mês
- ✅ **AWS** - Variável

---

## 🔧 **Comandos Úteis**

### **Desenvolvimento**
```bash
npm install          # Instalar dependências
npm run dev         # Executar em desenvolvimento
npm run build       # Gerar versão de produção
npm run preview     # Preview da versão de produção
```

### **Manutenção**
```bash
npm update          # Atualizar dependências
npm audit           # Verificar vulnerabilidades
npm audit fix       # Corrigir vulnerabilidades
```

---

## 📞 **Suporte**

### **Contatos Configurados**
- **WhatsApp:** (31) 98025-2882
- **Atendimento:** Segunda a Sábado, 8h às 18h
- **Região:** Vetor Norte de BH

### **Para Suporte Técnico**
- Verifique esta documentação primeiro
- Teste em ambiente de desenvolvimento
- Faça backup antes de mudanças
- Mantenha arquivos organizados

---

**✅ Site AutoLimpeza Pro desenvolvido com tecnologias modernas e otimizado para conversão de clientes via WhatsApp!**